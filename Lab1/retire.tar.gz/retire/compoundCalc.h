#ifndef compoundCalc_h
#define compoundCalc_h

//Function Prototypes
double compoundCalc(double, double, double);

#endif
